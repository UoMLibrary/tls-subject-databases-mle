// File#: _2_drawer-navigation
// Usage: codyhouse.co/license
(function () {
  function initDrNavControl(element) {
    var circle = element.getElementsByTagName("circle");
    if (circle.length > 0) {
      // set svg attributes to create fill-in animation on click
      initCircleAttributes(element, circle[0]);
    }

    var drawerId = element.getAttribute("aria-controls"),
      drawer = document.getElementById(drawerId);
    if (drawer) {
      // when the drawer is closed without click (e.g., user presses 'Esc') -> reset trigger status
      drawer.addEventListener("drawerIsClose", function (event) {
        if (
          !event.detail ||
          (event.detail &&
            !event.detail.closest(
              '.js-dr-nav-control[aria-controls="' + drawerId + '"]'
            ))
        )
          resetTrigger(element);
      });
    }
  }

  function initCircleAttributes(element, circle) {
    // set circle stroke-dashoffset/stroke-dasharray values
    var circumference = (2 * Math.PI * circle.getAttribute("r")).toFixed(2);
    circle.setAttribute("stroke-dashoffset", circumference);
    circle.setAttribute("stroke-dasharray", circumference);
    Util.addClass(element, "dr-nav-control--ready-to-animate");
  }

  function resetTrigger(element) {
    Util.removeClass(element, "anim-menu-btn--state-b");
  }

  var drNavControl = document.getElementsByClassName("js-dr-nav-control");
  if (drNavControl.length > 0) initDrNavControl(drNavControl[0]);
})();
